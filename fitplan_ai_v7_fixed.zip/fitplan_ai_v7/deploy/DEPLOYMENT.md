# FitPlan AI V7 Deployment

## 1. Backend locally
Install Docker, then:
```bash
cd backend
docker compose up --build
```

Test:
```bash
curl http://localhost:8000/health
curl http://localhost:8000/ready
```

## 2. Production API
Use a managed PostgreSQL database and a container platform such as Render/Railway/AWS/Azure/GCP.

Required secrets/config:
- `DATABASE_URL`
- `JWT_SECRET`
- `CORS_ORIGINS`
- `TRUSTED_HOSTS`
- optional `OPENAI_API_KEY`

Never commit `.env`.

## 3. Domain
Recommended:
- App/site: `fitplanai.in`
- API: `api.fitplanai.in`

Point DNS to your hosting provider and enable HTTPS.

## 4. Flutter Android
```bash
flutter pub get
flutter build appbundle --release --dart-define=API_BASE=https://api.fitplanai.in
```
Upload the generated `.aab` to Google Play Console.

## 5. iOS
On macOS with Xcode:
```bash
flutter build ipa --release --dart-define=API_BASE=https://api.fitplanai.in
```
Then upload through Xcode/Transporter/App Store Connect.

## 6. Before public launch
- Replace all demo nutrition/exercise data with reviewed production data.
- Add account deletion/export mechanisms.
- Add privacy policy and terms.
- Review health/medical claims and safety language.
- Add monitoring, backups, alerts and restore testing.
- Run dependency/security scans.
- Configure app signing and secure CI/CD secrets.
- Add production analytics/crash reporting.
- Perform load, auth, abuse and penetration testing.
