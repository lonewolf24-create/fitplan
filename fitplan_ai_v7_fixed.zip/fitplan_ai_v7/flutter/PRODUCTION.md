# Flutter Production Build

Run against your deployed API:

```bash
flutter run --dart-define=API_BASE=https://api.fitplanai.in
```

Android:
```bash
flutter build appbundle --release --dart-define=API_BASE=https://api.fitplanai.in
```

The V7 Flutter folder is a deployment configuration shell. Merge `api_config.dart` into the V6 UI/API code rather than replacing the existing product screens.
