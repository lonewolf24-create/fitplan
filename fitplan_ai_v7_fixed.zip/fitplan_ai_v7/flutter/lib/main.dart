import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'api_config.dart';

void main() => runApp(const FitPlanApp());

class FitPlanApp extends StatelessWidget {
  const FitPlanApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'FitPlan AI',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(useMaterial3: true, colorSchemeSeed: Colors.green),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('FitPlan AI')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Text('Your fitness companion', style: Theme.of(context).textTheme.headlineMedium?.copyWith(fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          const Text('Track meals faster with AI-powered camera nutrition analysis.'),
          const SizedBox(height: 24),
          Card(
            child: ListTile(
              leading: const CircleAvatar(child: Icon(Icons.camera_alt_outlined)),
              title: const Text('Scan Meal', style: TextStyle(fontWeight: FontWeight.bold)),
              subtitle: const Text('Photo → calories, protein, carbs, fats, fiber, sugar & sodium'),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const NutritionCameraPage())),
            ),
          ),
          const SizedBox(height: 16),
          const Card(
            child: Padding(
              padding: EdgeInsets.all(16),
              child: Text('Tip: AI nutrition values are estimates. Portion size, oil, sauces and hidden ingredients can change the actual numbers.'),
            ),
          ),
          const SizedBox(height: 20),
          Text('API: $apiBase', style: Theme.of(context).textTheme.bodySmall),
        ],
      ),
    );
  }
}

class NutritionCameraPage extends StatefulWidget {
  const NutritionCameraPage({super.key});

  @override
  State<NutritionCameraPage> createState() => _NutritionCameraPageState();
}

class _NutritionCameraPageState extends State<NutritionCameraPage> {
  final ImagePicker _picker = ImagePicker();
  File? _image;
  Map<String, dynamic>? _result;
  bool _loading = false;
  String? _error;

  Future<void> _pick(ImageSource source) async {
    final picked = await _picker.pickImage(source: source, imageQuality: 88, maxWidth: 1800);
    if (picked == null) return;
    setState(() { _image = File(picked.path); _result = null; _error = null; });
    await _analyze();
  }

  Future<void> _analyze() async {
    if (_image == null) return;
    setState(() { _loading = true; _error = null; });
    try {
      final prefs = await SharedPreferences.getInstance();
      final token = prefs.getString('access_token') ?? '';
      if (token.isEmpty) {
        throw Exception('Please sign in first and save your access token as access_token.');
      }
      final request = http.MultipartRequest('POST', Uri.parse('$apiBase/nutrition/analyze'));
      request.headers['Authorization'] = 'Bearer $token';
      request.files.add(await http.MultipartFile.fromPath('image', _image!.path));
      final streamed = await request.send();
      final response = await http.Response.fromStream(streamed);
      final body = jsonDecode(response.body);
      if (response.statusCode >= 400) {
        throw Exception(body is Map && body['detail'] != null ? body['detail'].toString() : 'Nutrition analysis failed.');
      }
      setState(() => _result = Map<String, dynamic>.from(body));
    } catch (e) {
      setState(() => _error = e.toString().replaceFirst('Exception: ', ''));
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Scan Meal')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          if (_image != null) ClipRRect(borderRadius: BorderRadius.circular(16), child: Image.file(_image!, height: 240, fit: BoxFit.cover)),
          if (_image == null) Container(height: 240, decoration: BoxDecoration(borderRadius: BorderRadius.circular(16), color: Theme.of(context).colorScheme.surfaceContainerHighest), child: const Icon(Icons.restaurant_outlined, size: 72)),
          const SizedBox(height: 16),
          Row(children: [
            Expanded(child: FilledButton.icon(onPressed: _loading ? null : () => _pick(ImageSource.camera), icon: const Icon(Icons.camera_alt), label: const Text('Take Photo'))),
            const SizedBox(width: 12),
            Expanded(child: OutlinedButton.icon(onPressed: _loading ? null : () => _pick(ImageSource.gallery), icon: const Icon(Icons.photo_library_outlined), label: const Text('Gallery'))),
          ]),
          if (_loading) const Padding(padding: EdgeInsets.all(24), child: Center(child: CircularProgressIndicator())),
          if (_error != null) Padding(padding: const EdgeInsets.only(top: 16), child: Card(child: Padding(padding: const EdgeInsets.all(16), child: Text(_error!)))),
          if (_result != null) _NutritionResult(result: _result!),
        ],
      ),
    );
  }
}

class _NutritionResult extends StatelessWidget {
  final Map<String, dynamic> result;
  const _NutritionResult({required this.result});

  @override
  Widget build(BuildContext context) {
    final total = Map<String, dynamic>.from(result['total'] ?? {});
    final items = (result['items'] as List? ?? []).cast<Map>();
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const SizedBox(height: 24),
      Text(result['meal_name']?.toString() ?? 'Meal', style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold)),
      const SizedBox(height: 8),
      Text('Confidence: ${result['confidence'] ?? 'unknown'}'),
      const SizedBox(height: 16),
      Card(child: Padding(padding: const EdgeInsets.all(16), child: Wrap(spacing: 20, runSpacing: 14, children: [
        _Metric('Calories', '${total['calories_kcal'] ?? 0} kcal'),
        _Metric('Protein', '${total['protein_g'] ?? 0} g'),
        _Metric('Carbs', '${total['carbs_g'] ?? 0} g'),
        _Metric('Fat', '${total['fat_g'] ?? 0} g'),
        _Metric('Fiber', '${total['fiber_g'] ?? 0} g'),
        _Metric('Sugar', '${total['sugar_g'] ?? 0} g'),
        _Metric('Sodium', '${total['sodium_mg'] ?? 0} mg'),
      ]))),
      const SizedBox(height: 16),
      Text('Detected foods', style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold)),
      ...items.map((raw) { final item = Map<String, dynamic>.from(raw); return ListTile(isThreeLine: true, contentPadding: EdgeInsets.zero, title: Text(item['food']?.toString() ?? 'Food'), subtitle: Text('${item['portion'] ?? 'portion'}\n${item['calories_kcal'] ?? 0} kcal • ${item['protein_g'] ?? 0} g protein • ${item['carbs_g'] ?? 0} g carbs • ${item['fat_g'] ?? 0} g fat')); }),
      if ((result['notes'] ?? '').toString().isNotEmpty) Padding(padding: const EdgeInsets.only(top: 8), child: Text('Notes: ${result['notes']}')),
    ]);
  }
}

class _Metric extends StatelessWidget {
  final String label, value;
  const _Metric(this.label, this.value);
  @override
  Widget build(BuildContext context) => SizedBox(width: 92, child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(label, style: Theme.of(context).textTheme.labelMedium), const SizedBox(height: 2), Text(value, style: const TextStyle(fontWeight: FontWeight.bold))]));
}
