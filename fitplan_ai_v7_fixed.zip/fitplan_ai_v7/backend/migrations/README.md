# Database migrations

V7 currently initializes the schema for first-run development with SQLAlchemy metadata.
Before a production launch with an existing database, add Alembic migrations and run them
as a controlled deployment step. Do not rely on `create_all()` for schema evolution.
