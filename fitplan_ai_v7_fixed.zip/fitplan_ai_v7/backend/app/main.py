import json, logging, time
from fastapi import FastAPI, Depends, HTTPException, Request, UploadFile, File
from fastapi.middleware.cors import CORSMiddleware
from starlette.middleware.trustedhost import TrustedHostMiddleware
from slowapi import Limiter
from slowapi.util import get_remote_address
from slowapi.middleware import SlowAPIMiddleware
from sqlalchemy.orm import Session
from .config import settings
from .db import Base, engine, get_db
from .models import User, Profile, Progress, Plan
from .schemas import RegisterIn, LoginIn, TokenOut, ProfileIn, ProfileOut, ProgressIn, ProgressOut
from .security import hash_password, verify_password, create_access_token
from .deps import current_user
from .engine import make_plan, adaptive_adjustment, analyze_food_image

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
logger = logging.getLogger("fitplan")

Base.metadata.create_all(bind=engine)

limiter = Limiter(key_func=get_remote_address)
app = FastAPI(title="FitPlan AI API", version="7.0.0")
app.state.limiter = limiter
app.add_middleware(SlowAPIMiddleware)
app.add_middleware(TrustedHostMiddleware, allowed_hosts=settings.trusted_host_list)
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_list,
    allow_credentials=True,
    allow_methods=["GET","POST","PUT","OPTIONS"],
    allow_headers=["Authorization","Content-Type"],
)

@app.middleware("http")
async def request_log(request: Request, call_next):
    started = time.perf_counter()
    response = await call_next(request)
    elapsed = (time.perf_counter() - started) * 1000
    logger.info("%s %s %s %.1fms", request.method, request.url.path, response.status_code, elapsed)
    return response

@app.get("/health")
def health():
    return {"status": "ok", "version": "7.0.0"}

@app.get("/ready")
def ready(db: Session = Depends(get_db)):
    try:
        db.execute(__import__("sqlalchemy").text("SELECT 1"))
        return {"status": "ready"}
    except Exception:
        raise HTTPException(status_code=503, detail="Database unavailable")

@app.post("/auth/register", response_model=TokenOut)
@limiter.limit("5/minute")
def register(request: Request, body: RegisterIn, db: Session = Depends(get_db)):
    if db.query(User).filter(User.email == body.email.lower()).first():
        raise HTTPException(409, "Email already registered")
    user = User(email=body.email.lower(), password_hash=hash_password(body.password))
    user.profile = Profile()
    db.add(user); db.commit(); db.refresh(user)
    return {"access_token": create_access_token(str(user.id))}

@app.post("/auth/login", response_model=TokenOut)
@limiter.limit("10/minute")
def login(request: Request, body: LoginIn, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.email == body.email.lower()).first()
    if not user or not verify_password(body.password, user.password_hash):
        raise HTTPException(401, "Invalid email or password")
    return {"access_token": create_access_token(str(user.id))}

@app.get("/me")
def me(user: User = Depends(current_user)):
    return {"id": user.id, "email": user.email}

@app.get("/profile", response_model=ProfileOut)
def get_profile(user: User = Depends(current_user)):
    return user.profile

@app.put("/profile", response_model=ProfileOut)
def update_profile(body: ProfileIn, user: User = Depends(current_user), db: Session = Depends(get_db)):
    profile = user.profile or Profile(user_id=user.id)
    for k, v in body.model_dump().items():
        setattr(profile, k, v)
    user.profile = profile
    db.add(user); db.commit(); db.refresh(profile)
    return profile

@app.post("/plan/generate")
def generate_plan(user: User = Depends(current_user), db: Session = Depends(get_db)):
    if not user.profile:
        raise HTTPException(400, "Complete your profile first")
    payload = make_plan(user.profile)
    db.add(Plan(user_id=user.id, payload=json.dumps(payload)))
    db.commit()
    return payload


@app.post("/nutrition/analyze")
@limiter.limit("10/minute")
async def analyze_nutrition(request: Request, image: UploadFile = File(...), user: User = Depends(current_user)):
    """Estimate nutrition from a meal photo using the backend AI key.

    The API key is never sent to Flutter. Results are estimates and should not be
    treated as a precise nutrition label, especially for mixed dishes.
    """
    if not image.content_type or not image.content_type.startswith("image/"):
        raise HTTPException(415, "Please upload an image file.")
    data = await image.read()
    if len(data) > 8 * 1024 * 1024:
        raise HTTPException(413, "Image must be 8 MB or smaller.")
    try:
        return await analyze_food_image(data, image.content_type)
    except ValueError as exc:
        raise HTTPException(400, str(exc))
    except RuntimeError as exc:
        logger.exception("Nutrition analysis failed")
        raise HTTPException(502, str(exc))

@app.post("/progress", response_model=ProgressOut)
def add_progress(body: ProgressIn, user: User = Depends(current_user), db: Session = Depends(get_db)):
    row = Progress(user_id=user.id, **body.model_dump())
    db.add(row); db.commit(); db.refresh(row)
    return row

@app.get("/progress", response_model=list[ProgressOut])
def get_progress(user: User = Depends(current_user), db: Session = Depends(get_db)):
    return db.query(Progress).filter(Progress.user_id == user.id).order_by(Progress.date.desc()).limit(90).all()

@app.get("/coach")
def coach(user: User = Depends(current_user), db: Session = Depends(get_db)):
    rows = db.query(Progress).filter(Progress.user_id == user.id).order_by(Progress.date.asc()).limit(90).all()
    if not user.profile:
        raise HTTPException(400, "Complete your profile first")
    return adaptive_adjustment(user.profile, rows)

@app.get("/coach/adjustment")
def coach_adjustment(user: User = Depends(current_user), db: Session = Depends(get_db)):
    rows = db.query(Progress).filter(Progress.user_id == user.id).order_by(Progress.date.asc()).limit(90).all()
    return adaptive_adjustment(user.profile, rows)
