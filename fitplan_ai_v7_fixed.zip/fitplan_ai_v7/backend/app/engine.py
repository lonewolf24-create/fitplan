from statistics import mean

FOODS = [
    {"name": "Oats + milk + banana", "diet": "vegetarian", "allergens": ["milk"], "protein": 15, "calories": 400},
    {"name": "Paneer bhurji + roti", "diet": "vegetarian", "allergens": ["milk"], "protein": 28, "calories": 520},
    {"name": "Dal + rice + salad", "diet": "vegetarian", "allergens": [], "protein": 18, "calories": 480},
    {"name": "Chicken + rice + vegetables", "diet": "non-vegetarian", "allergens": [], "protein": 42, "calories": 620},
    {"name": "Egg bhurji + toast", "diet": "eggetarian", "allergens": ["egg"], "protein": 25, "calories": 410},
]

def blocked(item, allergies):
    a = {x.strip().lower() for x in allergies.split(",") if x.strip()}
    return bool(a.intersection(set(item["allergens"])))

def targets(profile):
    # Simplified Mifflin-style estimate for demo/product foundation.
    if not profile.weight or not profile.height or not profile.age:
        return {"calories": 2000, "protein": 100}
    sex_adj = 5 if profile.sex.lower() in ("male", "m") else -161
    bmr = 10 * profile.weight + 6.25 * profile.height - 5 * profile.age + sex_adj
    mult = {"low": 1.25, "light": 1.375, "moderate": 1.55, "high": 1.725}.get(profile.activity.lower(), 1.55)
    calories = bmr * mult
    if profile.goal == "build muscle":
        calories += 200
    elif profile.goal == "lose fat":
        calories -= 300
    return {"calories": round(calories), "protein": round(profile.weight * 1.6)}

def make_plan(profile):
    allowed = [f for f in FOODS if f["diet"] in (profile.diet, "vegetarian") and not blocked(f, profile.allergies)]
    if not allowed:
        allowed = [f for f in FOODS if not blocked(f, profile.allergies)]
    chosen = (allowed * 3)[:7]
    return {"targets": targets(profile), "days": [{"day": i+1, "meal": chosen[i]["name"], "protein": chosen[i]["protein"], "calories": chosen[i]["calories"]} for i in range(7)]}

def adaptive_adjustment(profile, progress_rows):
    if len(progress_rows) < 7:
        return {"status": "insufficient_data", "message": "Log at least 7 days before changing calorie targets."}
    rows = sorted(progress_rows, key=lambda x: x.date)
    first = rows[0].weight
    last = rows[-1].weight
    delta = last - first
    if profile.goal == "build muscle" and delta < 0.1:
        return {"status": "adjust_up", "calorie_delta": 120, "message": "Consider increasing daily calories by about 120 kcal."}
    if profile.goal == "lose fat" and delta >= 0:
        return {"status": "adjust_down", "calorie_delta": -120, "message": "Consider reducing daily calories by about 120 kcal."}
    return {"status": "steady", "calorie_delta": 0, "message": "Current targets can remain steady."}


async def analyze_food_image(image_bytes: bytes, content_type: str):
    """Use OpenAI vision to identify food and return an auditable nutrition estimate."""
    import base64, json, httpx
    from .config import settings

    if not settings.openai_api_key:
        raise RuntimeError("Nutrition camera is not configured. Set OPENAI_API_KEY on the backend.")

    data_url = f"data:{content_type};base64,{base64.b64encode(image_bytes).decode('ascii')}"
    prompt = (
        "Analyze this meal photo for nutrition tracking. Identify each visible food and estimate "
        "the edible portion. Return ONLY valid JSON with this shape: "
        '{"meal_name":"string","items":[{"food":"string","portion":"string",'
        '"calories_kcal":0,"protein_g":0,"carbs_g":0,"fat_g":0,"fiber_g":0,'
        '"sugar_g":0,"sodium_mg":0}],"total":{"calories_kcal":0,"protein_g":0,'
        '"carbs_g":0,"fat_g":0,"fiber_g":0,"sugar_g":0,"sodium_mg":0},'
        '"confidence":"high|medium|low","notes":"string"}. '
        "Use numeric values. If an item cannot be identified confidently, say so in notes and "
        "use conservative estimates. Nutrition values are estimates, not laboratory measurements."
    )
    payload = {
        "model": "gpt-4o-mini",
        "temperature": 0.1,
        "max_tokens": 1200,
        "messages": [{"role": "user", "content": [
            {"type": "text", "text": prompt},
            {"type": "image_url", "image_url": {"url": data_url, "detail": "high"}},
        ]}],
    }
    headers = {"Authorization": f"Bearer {settings.openai_api_key}", "Content-Type": "application/json"}
    async with httpx.AsyncClient(timeout=45) as client:
        response = await client.post("https://api.openai.com/v1/chat/completions", headers=headers, json=payload)
    if response.status_code >= 400:
        raise RuntimeError("The nutrition vision service is temporarily unavailable.")
    try:
        content = response.json()["choices"][0]["message"]["content"]
        result = json.loads(content)
    except (KeyError, TypeError, json.JSONDecodeError) as exc:
        raise RuntimeError("The nutrition vision service returned an invalid result.") from exc
    return result
