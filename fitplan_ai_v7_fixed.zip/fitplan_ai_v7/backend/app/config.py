from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    app_env: str = "development"
    database_url: str = "sqlite:///./fitplan.db"
    jwt_secret: str = ""
    jwt_expire_minutes: int = 30
    cors_origins: str = "http://localhost:3000"
    trusted_hosts: str = "localhost,127.0.0.1"
    openai_api_key: str = ""

    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    @property
    def cors_list(self):
        return [x.strip() for x in self.cors_origins.split(",") if x.strip()]

    @property
    def trusted_host_list(self):
        return [x.strip() for x in self.trusted_hosts.split(",") if x.strip()]

settings = Settings()

if settings.app_env == "production" and len(settings.jwt_secret) < 32:
    raise RuntimeError("JWT_SECRET must be at least 32 characters in production.")
