from pydantic import BaseModel, EmailStr, Field, ConfigDict
from typing import Optional, Any

class RegisterIn(BaseModel):
    email: EmailStr
    password: str = Field(min_length=8, max_length=128)

class LoginIn(BaseModel):
    email: EmailStr
    password: str

class TokenOut(BaseModel):
    access_token: str
    token_type: str = "bearer"

class ProfileIn(BaseModel):
    name: str = ""
    age: Optional[int] = Field(default=None, ge=13, le=120)
    sex: str = ""
    weight: Optional[float] = Field(default=None, gt=0, le=500)
    height: Optional[float] = Field(default=None, gt=50, le=250)
    goal: str = "maintain"
    diet: str = "vegetarian"
    allergies: str = ""
    conditions: str = ""
    activity: str = "moderate"
    workout_days: int = Field(default=4, ge=0, le=7)
    workout_duration: int = Field(default=60, ge=10, le=240)
    budget: float = Field(default=0, ge=0)

class ProgressIn(BaseModel):
    weight: Optional[float] = Field(default=None, gt=0, le=500)
    steps: Optional[int] = Field(default=None, ge=0, le=200000)
    sleep_hours: Optional[float] = Field(default=None, ge=0, le=24)
    calories: Optional[float] = Field(default=None, ge=0, le=10000)
    protein: Optional[float] = Field(default=None, ge=0, le=1000)

class ProfileOut(ProfileIn):
    model_config = ConfigDict(from_attributes=True)

class ProgressOut(ProgressIn):
    id: int
    date: Any
    model_config = ConfigDict(from_attributes=True)
