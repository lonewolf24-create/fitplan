from datetime import datetime
from sqlalchemy import Column, Integer, String, Float, DateTime, Text, ForeignKey
from sqlalchemy.orm import relationship
from .db import Base

class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True)
    email = Column(String(320), unique=True, index=True, nullable=False)
    password_hash = Column(String(255), nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    profile = relationship("Profile", back_populates="user", uselist=False, cascade="all, delete-orphan")
    progress = relationship("Progress", back_populates="user", cascade="all, delete-orphan")

class Profile(Base):
    __tablename__ = "profiles"
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id"), unique=True, nullable=False)
    name = Column(String(120), default="")
    age = Column(Integer, nullable=True)
    sex = Column(String(30), default="")
    weight = Column(Float, nullable=True)
    height = Column(Float, nullable=True)
    goal = Column(String(40), default="maintain")
    diet = Column(String(60), default="vegetarian")
    allergies = Column(Text, default="")
    conditions = Column(Text, default="")
    activity = Column(String(40), default="moderate")
    workout_days = Column(Integer, default=4)
    workout_duration = Column(Integer, default=60)
    budget = Column(Float, default=0)
    user = relationship("User", back_populates="profile")

class Progress(Base):
    __tablename__ = "progress"
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False, index=True)
    date = Column(DateTime, default=datetime.utcnow, nullable=False)
    weight = Column(Float, nullable=True)
    steps = Column(Integer, nullable=True)
    sleep_hours = Column(Float, nullable=True)
    calories = Column(Float, nullable=True)
    protein = Column(Float, nullable=True)
    user = relationship("User", back_populates="progress")

class Plan(Base):
    __tablename__ = "plans"
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False, index=True)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    payload = Column(Text, nullable=False)
