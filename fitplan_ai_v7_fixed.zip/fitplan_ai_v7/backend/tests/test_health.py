import os
os.environ["DATABASE_URL"] = "sqlite:///./test_fitplan.db"
os.environ["JWT_SECRET"] = "test-secret-please-change-this-123456"
os.environ["APP_ENV"] = "development"
os.environ["TRUSTED_HOSTS"] = "testserver,localhost,127.0.0.1"
from fastapi.testclient import TestClient
from app.main import app

def test_health():
    with TestClient(app) as client:
        r = client.get("/health")
        assert r.status_code == 200
        assert r.json()["status"] == "ok"
