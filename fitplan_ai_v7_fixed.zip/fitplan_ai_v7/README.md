# FitPlan AI — V7 Production Deployment Foundation

V7 turns the V6 product foundation into a deployment-oriented project.

## Included
- FastAPI backend with PostgreSQL support
- Dockerfile + docker-compose for local production-like development
- Environment-based secrets/configuration
- CORS and trusted-host configuration
- Health/readiness endpoints
- Structured JSON logging
- JWT access tokens with configurable expiry
- Secure password hashing
- Basic request-rate limiting
- Pytest smoke tests
- GitHub Actions CI
- Render deployment blueprint
- Flutter production API configuration via `--dart-define`
- Android release build instructions
- Privacy/security deployment checklist

## Important
This is a deployment foundation, not a claim of regulatory or clinical compliance. Before public launch, review privacy policy/consent, medical and allergy safety, nutrition data quality, data retention/deletion, age requirements, app-store policies, payment/tax rules, and security with qualified professionals.

## Quick start — backend
```bash
cd backend
cp .env.example .env
docker compose up --build
```

API:
- `GET /health`
- `GET /ready`
- `POST /auth/register`
- `POST /auth/login`
- `GET /me`
- `PUT /profile`
- `POST /plan/generate`
- `POST /progress`
- `GET /progress`
- `GET /coach`
- `GET /coach/adjustment`
- `POST /nutrition/analyze` — upload a meal photo and receive estimated calories, protein, carbs, fat, fiber, sugar, sodium, portions, and confidence

OpenAPI docs locally: `http://localhost:8000/docs`

## Camera nutrition
The Flutter app now includes **Scan Meal**. For iOS builds, add `NSCameraUsageDescription` and `NSPhotoLibraryUsageDescription` to `Info.plist` as required by `image_picker`. It can take a photo or choose one from the gallery, then sends the image to `/nutrition/analyze`. The OpenAI key stays on the backend. Set `OPENAI_API_KEY` in the backend environment to enable the feature.

The camera result is an estimate: portion size, hidden ingredients, cooking oil, and mixed dishes can materially change nutrition values.

## Flutter
Set your deployed API:
```bash
flutter pub get
flutter run --dart-define=API_BASE=https://api.example.com
```

Android:
```bash
flutter build appbundle --release --dart-define=API_BASE=https://api.example.com
```

Do not put AI/API secrets inside Flutter. Secrets belong on the backend.

## Render
1. Push this project to GitHub.
2. Create a Render PostgreSQL database.
3. Create the web service using `deploy/render.yaml`, or configure the service manually.
4. Set `JWT_SECRET` to a long random secret.
5. Set `DATABASE_URL` to the managed PostgreSQL connection string.
6. Set `CORS_ORIGINS` to your app/web origins.
7. Set `TRUSTED_HOSTS` to your API hostname.
8. Add `OPENAI_API_KEY` only if AI enhancement is enabled.
9. Deploy and verify `/health` and `/ready`.

## Production checklist
- [ ] Managed PostgreSQL
- [ ] Strong secret values stored in platform secret manager
- [ ] HTTPS
- [ ] CORS restricted to real origins
- [ ] Trusted hosts restricted
- [ ] Database backups + restore test
- [ ] Monitoring and alerting
- [ ] Crash reporting for Flutter
- [ ] Privacy policy + terms
- [ ] Account/data deletion flow
- [ ] Security review
- [ ] Nutrition/exercise dataset review
- [ ] Human-reviewed safety copy for medical/allergy use
- [ ] Google Play / App Store policy review
